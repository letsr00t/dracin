"use client";

import { UnifiedErrorDisplay } from "@/components/UnifiedErrorDisplay";
import { useDramaDetail } from "@/hooks/useDramaDetail";
import { Play, Calendar, ChevronLeft, Film, Flame } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import Link from "next/link";
import { useRouter, useParams } from "next/navigation";
import type { DramaDetailDirect, DramaDetailResponseLegacy } from "@/types/drama";

function isDirectFormat(data: unknown): data is DramaDetailDirect {
  return data !== null && typeof data === "object" && "bookId" in data && "coverWap" in data;
}

function isLegacyFormat(data: unknown): data is DramaDetailResponseLegacy {
  return data !== null && typeof data === "object" && "data" in data && (data as DramaDetailResponseLegacy).data?.book !== undefined;
}

export default function DramaBoxDetailPage() {
  const params = useParams<{ bookId: string }>();
  const bookId = params.bookId;
  const router = useRouter();
  const { data, isLoading, error } = useDramaDetail(bookId || "");

  if (isLoading) return <DetailSkeleton />;

  let book: {
    bookId: string;
    bookName: string;
    cover: string;
    chapterCount: number;
    introduction: string;
    tags?: string[];
    shelfTime?: string;
  } | null = null;

  if (isDirectFormat(data)) {
    book = {
      bookId: data.bookId,
      bookName: data.bookName,
      cover: data.coverWap,
      chapterCount: data.chapterCount,
      introduction: data.introduction,
      tags: data.tags || data.tagV3s?.map((t) => t.tagName),
      shelfTime: data.shelfTime,
    };
  } else if (isLegacyFormat(data)) {
    book = {
      bookId: data.data.book.bookId,
      bookName: data.data.book.bookName,
      cover: data.data.book.cover,
      chapterCount: data.data.book.chapterCount,
      introduction: data.data.book.introduction,
      tags: data.data.book.tags,
      shelfTime: data.data.book.shelfTime,
    };
  }

  if (error || !book) {
    return (
      <div className="min-h-screen pt-24 px-4">
        <UnifiedErrorDisplay
          title="Drama tidak ditemukan"
          message="Tidak dapat memuat detail drama. Silakan coba lagi atau kembali ke beranda."
          onRetry={() => router.push("/")}
          retryLabel="Kembali ke Beranda"
        />
      </div>
    );
  }

  return (
    <main className="min-h-screen pt-20">
      {/* Cinematic blurred background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ height: '70vh' }}>
        <img
          src={book.cover}
          alt=""
          className="w-full h-full object-cover opacity-15 blur-2xl scale-110"
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, hsl(0,0%,5%,0.4) 0%, hsl(0,0%,5%) 100%)' }} />
        {/* Red glow overlay */}
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 50% 0%, hsl(4,90%,30%,0.12) 0%, transparent 70%)' }} />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 py-8">
        {/* Back Button */}
        <button
          onClick={() => router.back()}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8 group"
        >
          <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-medium">Kembali</span>
        </button>

        <div className="grid grid-cols-1 md:grid-cols-[260px_1fr] gap-8 md:gap-12">
          {/* Cover */}
          <div className="flex flex-col items-center md:items-start gap-4">
            <div className="relative group w-full max-w-[220px] md:max-w-full">
              <img
                src={book.cover}
                alt={book.bookName}
                className="w-full rounded-2xl object-cover"
                style={{ boxShadow: '0 20px 60px hsl(4,90%,20%,0.4), 0 8px 20px rgba(0,0,0,0.6)' }}
              />
              {/* Hover play overlay */}
              <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6"
                style={{ background: 'linear-gradient(to top, hsl(0,0%,0%,0.85) 0%, transparent 60%)' }}>
                <Link
                  href={`/watch/dramabox/${book.bookId}`}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full text-white font-semibold text-sm transition-all hover:scale-105"
                  style={{ background: 'linear-gradient(135deg, hsl(4,90%,50%), hsl(20,95%,55%))', boxShadow: '0 4px 20px hsl(4,90%,40%,0.5)' }}
                >
                  <Play className="w-4 h-4 fill-white" />
                  Tonton
                </Link>
              </div>
            </div>

            {/* Mobile watch button */}
            <Link
              href={`/watch/dramabox/${book.bookId}`}
              className="md:hidden w-full max-w-[220px] flex items-center justify-center gap-2 py-3 rounded-xl text-white font-semibold transition-all hover:scale-105"
              style={{ background: 'linear-gradient(135deg, hsl(4,90%,50%), hsl(20,95%,55%))', boxShadow: '0 4px 20px hsl(4,90%,40%,0.4)' }}
            >
              <Play className="w-4 h-4 fill-white" />
              Tonton Sekarang
            </Link>
          </div>

          {/* Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold gradient-text mb-4 leading-tight">
                {book.bookName}
              </h1>

              {/* Stats row */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium"
                  style={{ background: 'hsl(4,90%,40%,0.15)', border: '1px solid hsl(4,90%,55%,0.3)', color: 'hsl(4,90%,70%)' }}>
                  <Film className="w-3.5 h-3.5" />
                  <span>{book.chapterCount} Episode</span>
                </div>
                {book.shelfTime && (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium"
                    style={{ background: 'hsl(0,0%,100%,0.05)', border: '1px solid hsl(0,0%,100%,0.1)', color: 'hsl(0,0%,70%)' }}>
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{book.shelfTime?.split(" ")[0]}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Tags */}
            {book.tags && book.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {book.tags.map((tag) => (
                  <span key={tag} className="tag-pill text-xs">{tag}</span>
                ))}
              </div>
            )}

            {/* Synopsis */}
            <div className="rounded-xl p-5 space-y-2"
              style={{ background: 'hsl(0,0%,100%,0.04)', border: '1px solid hsl(0,0%,100%,0.08)' }}>
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <Flame className="w-4 h-4" style={{ color: 'hsl(4,90%,60%)' }} />
                Sinopsis
              </h3>
              <p className="text-foreground/80 leading-relaxed text-sm md:text-base">
                {book.introduction}
              </p>
            </div>

            {/* Desktop Watch Button */}
            <Link
              href={`/watch/dramabox/${book.bookId}`}
              className="hidden md:inline-flex items-center gap-2.5 px-8 py-3.5 rounded-full font-bold text-white transition-all hover:scale-105"
              style={{
                background: 'linear-gradient(135deg, hsl(4,90%,50%), hsl(20,95%,55%))',
                boxShadow: '0 6px 28px hsl(4,90%,40%,0.5)',
              }}
            >
              <Play className="w-5 h-5 fill-white" />
              Mulai Menonton
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
}

function DetailSkeleton() {
  return (
    <main className="min-h-screen pt-24 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-[260px_1fr] gap-8 md:gap-12">
          <Skeleton className="aspect-[2/3] w-full max-w-[260px] rounded-2xl" />
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4" />
            <div className="flex gap-2">
              <Skeleton className="h-8 w-28 rounded-full" />
              <Skeleton className="h-8 w-24 rounded-full" />
            </div>
            <div className="flex gap-2">
              <Skeleton className="h-7 w-16 rounded-full" />
              <Skeleton className="h-7 w-20 rounded-full" />
              <Skeleton className="h-7 w-14 rounded-full" />
            </div>
            <Skeleton className="h-36 w-full rounded-xl" />
            <Skeleton className="h-12 w-48 rounded-full" />
          </div>
        </div>
      </div>
    </main>
  );
}
