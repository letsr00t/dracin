import Link from "next/link";
import { Flame } from "lucide-react";

export default function NotFound() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4 relative overflow-hidden">
      {/* Background glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] rounded-full blur-3xl opacity-15 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, hsl(4,90%,50%) 0%, transparent 70%)' }}
      />

      <div className="relative flex flex-col items-center gap-5 text-center">
        {/* Icon */}
        <div
          className="w-20 h-20 rounded-3xl flex items-center justify-center mb-2"
          style={{
            background: 'linear-gradient(135deg, hsl(4,90%,40%,0.25), hsl(20,95%,50%,0.15))',
            border: '1px solid hsl(4,90%,55%,0.3)',
            boxShadow: '0 0 40px hsl(4,90%,40%,0.2)',
          }}
        >
          <Flame className="w-10 h-10" style={{ color: 'hsl(4,90%,60%)' }} />
        </div>

        <h1
          className="font-display-hero text-8xl md:text-9xl gradient-text"
          style={{ textShadow: '0 0 60px hsl(4,90%,40%,0.4)' }}
        >
          404
        </h1>

        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-foreground">Halaman Tidak Ditemukan</h2>
          <p className="text-muted-foreground max-w-md">
            Maaf, halaman yang kamu cari tidak ada atau sudah dipindahkan.
          </p>
        </div>

        <Link
          href="/"
          className="mt-2 px-8 py-3 rounded-full font-semibold text-white transition-all hover:scale-105 hover:shadow-xl"
          style={{
            background: 'linear-gradient(135deg, hsl(4,90%,50%), hsl(20,95%,55%))',
            boxShadow: '0 4px 24px hsl(4,90%,40%,0.5)',
          }}
        >
          Kembali ke Beranda
        </Link>
      </div>
    </main>
  );
}
