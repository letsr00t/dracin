"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import { Flame, X } from "lucide-react";

export default function QrisDonationPopup() {
  const [isVisible, setIsVisible] = useState(false);
  const [countdown, setCountdown] = useState(10);

  useEffect(() => {
    setIsVisible(true);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) { clearInterval(timer); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-300"
      style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}>
      <div
        className="w-full max-w-sm rounded-2xl overflow-hidden flex flex-col items-center p-6 animate-in zoom-in-95 duration-400"
        style={{
          background: 'linear-gradient(145deg, hsl(0,0%,10%) 0%, hsl(4,10%,8%) 100%)',
          border: '1px solid hsl(4,90%,40%,0.25)',
          boxShadow: '0 20px 60px hsl(4,90%,20%,0.4), 0 0 0 1px hsl(0,0%,15%)',
        }}
      >
        {/* Header */}
        <div className="flex items-center gap-2.5 mb-2">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, hsl(4,90%,45%), hsl(20,95%,50%))', boxShadow: '0 0 16px hsl(4,90%,40%,0.5)' }}>
            <Flame className="w-4 h-4 text-white fill-white" />
          </div>
          <span className="font-display-hero text-xl gradient-text tracking-wider">DRACINBOSS</span>
        </div>

        <div
          className="w-20 h-px mb-5"
          style={{ background: 'linear-gradient(to right, transparent, hsl(4,90%,55%,0.5), transparent)' }}
        />

        <div className="text-center space-y-2 mb-6">
          <h2 className="text-lg font-bold text-white leading-snug">
            Dukung DracinBoss!
          </h2>
          <p className="text-sm text-white/50 leading-relaxed max-w-[260px] mx-auto">
            Donasi kamu membantu menambah platform drama & menjaga server tetap aktif. 🙏
          </p>
        </div>

        {/* QRIS Image */}
        <div
          className="relative w-52 h-52 rounded-2xl overflow-hidden transition-transform hover:scale-105 duration-300"
          style={{
            border: '2px solid hsl(4,90%,40%,0.4)',
            boxShadow: '0 8px 32px hsl(4,90%,20%,0.4)',
          }}
        >
          <Image
            src="/qris.jpg"
            alt="QRIS Donation"
            fill
            className="object-cover"
            priority
          />
        </div>

        <p className="mt-3 text-xs text-white/30 font-medium">
          Scan QRIS di atas untuk berdonasi
        </p>

        {/* Close Button */}
        <div className="mt-6 w-full">
          <button
            onClick={() => setIsVisible(false)}
            disabled={countdown > 0}
            className="w-full py-3 px-4 rounded-xl font-bold transition-all duration-300 flex items-center justify-center gap-2"
            style={countdown > 0 ? {
              background: 'hsl(0,0%,14%)',
              color: 'hsl(0,0%,40%)',
              cursor: 'not-allowed',
            } : {
              background: 'linear-gradient(135deg, hsl(4,90%,50%), hsl(20,95%,55%))',
              color: 'white',
              boxShadow: '0 4px 20px hsl(4,90%,40%,0.5)',
            }}
          >
            {countdown > 0 ? (
              <>
                <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Tutup dalam {countdown}s
              </>
            ) : (
              <>
                <X className="w-4 h-4" />
                Lanjut Nonton
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
