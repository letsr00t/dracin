"use client";

import { ExternalLink, Flame } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export function Footer() {
  const pathname = usePathname();

  if (pathname?.startsWith("/watch")) {
    return null;
  }

  return (
    <footer className="border-t border-white/5 mt-8" style={{ background: 'linear-gradient(to top, hsl(0,0%,4%) 0%, hsl(0,0%,6%) 100%)' }}>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center justify-center gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, hsl(4,90%,45%), hsl(38,95%,50%))', boxShadow: '0 0 14px hsl(4,90%,40%,0.4)' }}>
              <Flame className="w-4 h-4 text-white fill-white" />
            </div>
            <span className="font-display-hero text-xl gradient-text tracking-wider">DRACINBOSS</span>
          </div>

          <div className="w-24 h-px" style={{ background: 'linear-gradient(to right, transparent, hsl(4,90%,55%,0.5), transparent)' }} />

          <p className="text-sm text-muted-foreground text-center">
            Powered by{" "}
            <a
              href="https://api.sansekai.my.id"
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold hover:text-primary transition-colors inline-flex items-center gap-1"
              style={{ color: 'hsl(38,95%,55%)' }}
            >
              SΛNSΞKΛI API
              <ExternalLink className="w-3 h-3" />
            </a>
          </p>

          <p className="text-xs text-muted-foreground/60 text-center">
            © {new Date().getFullYear()} DracinBoss · Made with ❤️ by Yusril
          </p>
        </div>
      </div>
    </footer>
  );
}
