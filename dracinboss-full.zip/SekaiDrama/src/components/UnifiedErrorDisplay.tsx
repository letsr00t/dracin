import { AlertCircle, RefreshCw } from "lucide-react";

interface UnifiedErrorDisplayProps {
  message?: string;
  onRetry?: () => void;
  title?: string;
  retryLabel?: string;
}

export function UnifiedErrorDisplay({
  message = "Terjadi kesalahan saat memuat data.",
  title = "Gagal Memuat",
  onRetry,
  retryLabel = "Coba Lagi",
}: UnifiedErrorDisplayProps) {
  return (
    <div
      className="flex flex-col items-center justify-center p-8 md:p-12 text-center space-y-6 rounded-2xl border mx-auto max-w-4xl w-full"
      style={{
        background: 'linear-gradient(145deg, hsl(0,0%,10%) 0%, hsl(4,10%,8%) 100%)',
        borderColor: 'hsl(4,90%,40%,0.2)',
      }}
    >
      <div
        className="rounded-full p-4"
        style={{
          background: 'hsl(4,90%,40%,0.1)',
          boxShadow: '0 0 30px hsl(4,90%,40%,0.15)',
          border: '1px solid hsl(4,90%,40%,0.2)',
        }}
      >
        <AlertCircle className="w-8 h-8" style={{ color: 'hsl(4,90%,60%)' }} />
      </div>
      <div className="space-y-2">
        <h3 className="font-bold text-lg md:text-xl text-white">{title}</h3>
        <p className="text-sm text-white/50 max-w-sm mx-auto">{message}</p>
      </div>
      {onRetry && (
        <button
          onClick={onRetry}
          className="flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold transition-all hover:scale-105"
          style={{
            background: 'linear-gradient(135deg, hsl(4,90%,45%), hsl(20,95%,50%))',
            boxShadow: '0 4px 20px hsl(4,90%,40%,0.4)',
            color: 'white',
          }}
        >
          <RefreshCw className="w-4 h-4" />
          <span>{retryLabel}</span>
        </button>
      )}
    </div>
  );
}
