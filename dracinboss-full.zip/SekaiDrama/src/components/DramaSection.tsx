"use client";

import { UnifiedMediaCard } from "./UnifiedMediaCard";
import { UnifiedMediaCardSkeleton } from "./UnifiedMediaCardSkeleton";
import { UnifiedErrorDisplay } from "./UnifiedErrorDisplay";
import type { Drama } from "@/types/drama";

interface DramaSectionProps {
  title: string;
  dramas?: Drama[];
  isLoading?: boolean;
  error?: boolean;
  onRetry?: () => void;
}

export function DramaSection({ title, dramas, isLoading, error, onRetry }: DramaSectionProps) {
  if (error) {
    return (
      <section>
        <SectionTitle title={title} />
        <UnifiedErrorDisplay
          title={`Gagal Memuat ${title}`}
          message="Tidak dapat mengambil data drama."
          onRetry={onRetry}
        />
      </section>
    );
  }

  if (isLoading) {
    return (
      <section className="space-y-4">
        <div className="flex items-center gap-3 mb-5">
          <div className="w-1 h-6 rounded-full animate-pulse" style={{ background: 'hsl(4,90%,55%)' }} />
          <div className="h-6 w-36 rounded-lg animate-pulse" style={{ background: 'hsl(0,0%,14%)' }} />
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-3 md:gap-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <UnifiedMediaCardSkeleton key={i} index={i} />
          ))}
        </div>
      </section>
    );
  }

  return (
    <section>
      <SectionTitle title={title} />
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-3 md:gap-4">
        {dramas?.slice(0, 16).map((drama, index) => {
          const isPopular = drama.corner?.name?.toLowerCase().includes("populer");
          const badgeColor = isPopular ? "#E52E2E" : drama.corner?.color || "#e5a00d";

          return (
            <UnifiedMediaCard
              key={drama.bookId || `drama-${index}`}
              index={index}
              title={drama.bookName}
              cover={drama.coverWap || drama.cover || ""}
              link={`/detail/dramabox/${drama.bookId}`}
              episodes={drama.chapterCount}
              topLeftBadge={
                drama.corner
                  ? { text: drama.corner.name, color: badgeColor }
                  : null
              }
              topRightBadge={
                drama.rankVo
                  ? { text: drama.rankVo.hotCode, isTransparent: true }
                  : null
              }
            />
          );
        })}
      </div>
    </section>
  );
}

function SectionTitle({ title }: { title: string }) {
  return (
    <div className="flex items-center gap-3 mb-5">
      <div
        className="w-1 h-6 rounded-full flex-shrink-0"
        style={{
          background: 'linear-gradient(to bottom, hsl(4,90%,55%), hsl(20,95%,55%))',
          boxShadow: '0 0 10px hsl(4,90%,55%,0.6)',
        }}
      />
      <h2 className="font-bold text-lg md:text-xl text-foreground tracking-tight">{title}</h2>
    </div>
  );
}
