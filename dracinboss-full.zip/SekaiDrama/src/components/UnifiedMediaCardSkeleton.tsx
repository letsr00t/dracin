interface UnifiedMediaCardSkeletonProps {
  index?: number;
}

export function UnifiedMediaCardSkeleton({ index = 0 }: UnifiedMediaCardSkeletonProps) {
  return (
    <div
      className="rounded-xl overflow-hidden animate-fade-up w-full"
      style={{ animationDelay: `${index * 40}ms` }}
    >
      {/* Cover Skeleton */}
      <div className="aspect-[2/3] relative overflow-hidden rounded-xl"
        style={{ background: 'hsl(0,0%,12%)' }}>
        <div
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, hsl(0,0%,18%) 50%, transparent 100%)',
            backgroundSize: '200% 100%',
            animation: 'shimmer 1.6s linear infinite',
          }}
        />
        {/* Subtle red tint at bottom */}
        <div className="absolute inset-x-0 bottom-0 h-1/3"
          style={{ background: 'linear-gradient(to top, hsl(4,50%,10%,0.4), transparent)' }} />
      </div>

      {/* Text Skeletons */}
      <div className="pt-2.5 pb-1 space-y-1.5">
        <div className="h-2.5 rounded-full w-full" style={{ background: 'hsl(0,0%,14%)' }} />
        <div className="h-2.5 rounded-full w-3/5" style={{ background: 'hsl(0,0%,12%)' }} />
      </div>
    </div>
  );
}
