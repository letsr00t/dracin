import { Sparkles, TrendingUp, Clock, Play, Flame } from "lucide-react";

interface HeroSectionProps {
  title: string;
  description: string;
  icon?: "sparkles" | "trending" | "clock" | "play" | "flame";
}

const icons = {
  sparkles: Sparkles,
  trending: TrendingUp,
  clock: Clock,
  play: Play,
  flame: Flame,
};

export function HeroSection({ title, description, icon = "flame" }: HeroSectionProps) {
  const IconComponent = icons[icon] || Flame;

  return (
    <div className="relative pt-24 pb-8 md:pt-28 md:pb-12 overflow-hidden">
      {/* Background glow blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute -top-20 left-1/4 w-[500px] h-[300px] rounded-full blur-3xl opacity-20"
          style={{ background: 'radial-gradient(ellipse, hsl(4,90%,50%) 0%, transparent 70%)' }}
        />
        <div
          className="absolute top-0 right-1/4 w-[300px] h-[200px] rounded-full blur-3xl opacity-10"
          style={{ background: 'radial-gradient(ellipse, hsl(38,95%,55%) 0%, transparent 70%)' }}
        />
      </div>

      <div className="relative container mx-auto px-4">
        <div className="flex items-center gap-4 mb-3">
          <div
            className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
            style={{
              background: 'linear-gradient(135deg, hsl(4,90%,40%,0.3), hsl(20,95%,50%,0.2))',
              border: '1px solid hsl(4,90%,55%,0.3)',
              boxShadow: '0 0 24px hsl(4,90%,40%,0.2)',
            }}
          >
            <IconComponent className="w-6 h-6" style={{ color: 'hsl(4,90%,60%)' }} />
          </div>
          <h1 className="font-display-hero text-4xl md:text-5xl lg:text-6xl gradient-text tracking-wider">
            {title}
          </h1>
        </div>
        <p className="text-muted-foreground text-base md:text-lg max-w-2xl ml-16">
          {description}
        </p>
      </div>
    </div>
  );
}
