const express = require("express");
const cors = require("cors");
const axios = require("axios");
const https = require("https");
const http = require("http");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// ─── Axios instance dengan timeout & user-agent ───────────────────────────────
const api = axios.create({
  timeout: 15000,
  headers: {
    "User-Agent": "okhttp/4.12.0",
    "Accept": "application/json",
  },
  httpsAgent: new https.Agent({ rejectUnauthorized: false }),
});

// ─── Helper ───────────────────────────────────────────────────────────────────
function ok(res, data) {
  return res.json({ success: true, data });
}

function fail(res, msg = "Internal Server Error", status = 500) {
  return res.status(status).json({ success: false, error: msg });
}

async function fetchJSON(url, headers = {}) {
  const resp = await api.get(url, { headers });
  return resp.data;
}

// ══════════════════════════════════════════════════════════════════════════════
//  DRAMABOX — scrape dari API publik DramaBox
// ══════════════════════════════════════════════════════════════════════════════
const DB_BASE = "https://www.dramabox.com/api";
const DB_HEADERS = {
  "User-Agent": "okhttp/4.12.0",
  "Accept-Language": "id",
  "countryCode": "ID",
};

// Normalize DramaBox item
function normDB(item) {
  if (!item) return null;
  return {
    bookId: String(item.bookId || item.comicId || ""),
    bookName: item.bookName || item.comicName || item.name || "",
    cover: item.coverWap || item.cover || item.picUrl || "",
    coverWap: item.coverWap || item.cover || "",
    chapterCount: item.chapterCount || item.episodeCount || 0,
    introduction: item.introduction || item.desc || "",
    tags: item.tagNames || [],
    shelfTime: item.shelfTime || "",
    corner: item.corner || null,
    rankVo: item.rankVo || null,
    protagonist: item.protagonist || "",
  };
}

// GET /api/dramabox/latest
app.get("/api/dramabox/latest", async (req, res) => {
  try {
    const data = await fetchJSON(
      `${DB_BASE}/comic/mainpage/newrelease/list?pageSize=24&page=1&countryCode=ID`,
      DB_HEADERS
    );
    const items = (data?.data?.comicInfoList || data?.data || [])
      .map(normDB)
      .filter((i) => i && i.bookId);
    return ok(res, items);
  } catch (e) {
    console.error("DB latest:", e.message);
    return fail(res, e.message);
  }
});

// GET /api/dramabox/trending
app.get("/api/dramabox/trending", async (req, res) => {
  try {
    const data = await fetchJSON(
      `${DB_BASE}/comic/mainpage/recommend/list?pageSize=24&page=1&countryCode=ID`,
      DB_HEADERS
    );
    const items = (data?.data?.comicInfoList || data?.data || [])
      .map(normDB)
      .filter((i) => i && i.bookId);
    return ok(res, items);
  } catch (e) {
    console.error("DB trending:", e.message);
    return fail(res, e.message);
  }
});

// GET /api/dramabox/dubindo
app.get("/api/dramabox/dubindo", async (req, res) => {
  const page = req.query.page || 1;
  try {
    const data = await fetchJSON(
      `${DB_BASE}/comic/mainpage/dub/list?pageSize=24&page=${page}&countryCode=ID&language=id`,
      DB_HEADERS
    );
    const items = (data?.data?.comicInfoList || data?.data || [])
      .map(normDB)
      .filter((i) => i && i.bookId);
    return ok(res, items);
  } catch (e) {
    console.error("DB dubindo:", e.message);
    // fallback: return latest
    try {
      const data2 = await fetchJSON(
        `${DB_BASE}/comic/mainpage/newrelease/list?pageSize=24&page=${page}&countryCode=ID`,
        DB_HEADERS
      );
      const items2 = (data2?.data?.comicInfoList || data2?.data || [])
        .map(normDB)
        .filter((i) => i && i.bookId);
      return ok(res, items2);
    } catch (e2) {
      return fail(res, e2.message);
    }
  }
});

// GET /api/dramabox/foryou?page=1
app.get("/api/dramabox/foryou", async (req, res) => {
  const page = req.query.page || 1;
  try {
    const data = await fetchJSON(
      `${DB_BASE}/comic/mainpage/recommend/list?pageSize=24&page=${page}&countryCode=ID`,
      DB_HEADERS
    );
    const items = (data?.data?.comicInfoList || data?.data || [])
      .map(normDB)
      .filter((i) => i && i.bookId);
    return ok(res, items);
  } catch (e) {
    console.error("DB foryou:", e.message);
    return fail(res, e.message);
  }
});

// GET /api/dramabox/search?query=xxx
app.get("/api/dramabox/search", async (req, res) => {
  const query = req.query.query;
  if (!query) return ok(res, []);
  try {
    const data = await fetchJSON(
      `${DB_BASE}/comic/search?keyword=${encodeURIComponent(query)}&page=1&pageSize=20&countryCode=ID`,
      DB_HEADERS
    );
    const items = (data?.data?.comicInfoList || data?.data || [])
      .map(normDB)
      .filter((i) => i && i.bookId);
    return ok(res, items);
  } catch (e) {
    console.error("DB search:", e.message);
    return fail(res, e.message);
  }
});

// GET /api/dramabox/detail?bookId=xxx
app.get("/api/dramabox/detail", async (req, res) => {
  const { bookId } = req.query;
  if (!bookId) return fail(res, "bookId required", 400);
  try {
    const data = await fetchJSON(
      `${DB_BASE}/comic/detail?comicId=${bookId}&countryCode=ID`,
      DB_HEADERS
    );
    const raw = data?.data?.comicInfo || data?.data || data;
    return ok(res, normDB(raw));
  } catch (e) {
    console.error("DB detail:", e.message);
    return fail(res, e.message);
  }
});

// GET /api/dramabox/allepisode?bookId=xxx
app.get("/api/dramabox/allepisode", async (req, res) => {
  const { bookId } = req.query;
  if (!bookId) return fail(res, "bookId required", 400);
  try {
    const data = await fetchJSON(
      `${DB_BASE}/comic/episode/list?comicId=${bookId}&countryCode=ID&pageSize=500&page=1`,
      DB_HEADERS
    );
    const episodes = (data?.data?.episodeList || data?.data || []).map((ep) => ({
      chapterId: String(ep.episodeId || ep.chapterId || ""),
      chapterName: ep.episodeName || ep.chapterName || `Episode ${ep.episodeNo}`,
      chapterImg: ep.cover || ep.chapterImg || "",
      chapterCount: ep.episodeNo || 0,
      cdnList: ep.cdnList || [],
      useMultiSubtitle: ep.useMultiSubtitle || 0,
      subLanguageVoList: ep.subLanguageVoList || [],
    }));
    return ok(res, episodes);
  } catch (e) {
    console.error("DB allepisode:", e.message);
    return fail(res, e.message);
  }
});

// GET /api/dramabox/decrypt-stream?url=xxx  — proxy video stream
app.get("/api/dramabox/decrypt-stream", async (req, res) => {
  const videoUrl = req.query.url;
  if (!videoUrl) return res.status(400).send("Missing url");

  try {
    const range = req.headers.range;
    const headers = {
      "User-Agent": "okhttp/4.12.0",
      "Accept": "*/*",
      "Referer": "https://www.dramabox.com/",
    };
    if (range) headers["Range"] = range;

    const upstream = await axios({
      method: "GET",
      url: videoUrl,
      responseType: "stream",
      headers,
      httpsAgent: new https.Agent({ rejectUnauthorized: false }),
      maxRedirects: 5,
    });

    res.setHeader("Content-Type", upstream.headers["content-type"] || "video/mp4");
    res.setHeader("Accept-Ranges", "bytes");
    res.setHeader("Access-Control-Allow-Origin", "*");
    if (upstream.headers["content-length"])
      res.setHeader("Content-Length", upstream.headers["content-length"]);
    if (upstream.headers["content-range"])
      res.setHeader("Content-Range", upstream.headers["content-range"]);

    res.status(upstream.status);
    upstream.data.pipe(res);
  } catch (e) {
    console.error("decrypt-stream:", e.message);
    res.status(500).send("Stream error");
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  REELSHORT
// ══════════════════════════════════════════════════════════════════════════════
const RS_BASE = "https://api.reelshort.com";
const RS_HEADERS = {
  "User-Agent": "okhttp/4.12.0",
  "platform": "android",
  "version": "3.0.0",
};

app.get("/api/reelshort/homepage", async (req, res) => {
  try {
    const data = await fetchJSON(`${RS_BASE}/bs-api/home/page`, RS_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    console.error("RS homepage:", e.message);
    // Return empty structure so UI doesn't crash
    return ok(res, { bannerList: [], sectionList: [] });
  }
});

app.get("/api/reelshort/foryou", async (req, res) => {
  const page = req.query.page || 1;
  try {
    const data = await fetchJSON(
      `${RS_BASE}/bs-api/book/list?pageNum=${page}&pageSize=20&type=1`,
      RS_HEADERS
    );
    return ok(res, data?.data || []);
  } catch (e) {
    console.error("RS foryou:", e.message);
    return ok(res, []);
  }
});

app.get("/api/reelshort/search", async (req, res) => {
  const { query } = req.query;
  if (!query) return ok(res, { data: [] });
  try {
    const data = await fetchJSON(
      `${RS_BASE}/bs-api/book/search?keyword=${encodeURIComponent(query)}&pageNum=1&pageSize=20`,
      RS_HEADERS
    );
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, { data: [] });
  }
});

app.get("/api/reelshort/detail", async (req, res) => {
  const { bookId } = req.query;
  if (!bookId) return fail(res, "bookId required", 400);
  try {
    const data = await fetchJSON(
      `${RS_BASE}/bs-api/book/detail?bookId=${bookId}`,
      RS_HEADERS
    );
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

app.get("/api/reelshort/episode", async (req, res) => {
  const { bookId, episodeNumber } = req.query;
  if (!bookId || !episodeNumber) return fail(res, "bookId and episodeNumber required", 400);
  try {
    const data = await fetchJSON(
      `${RS_BASE}/bs-api/book/episode/detail?bookId=${bookId}&episodeNo=${episodeNumber}`,
      RS_HEADERS
    );
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  SHORTMAX
// ══════════════════════════════════════════════════════════════════════════════
const SM_BASE = "https://www.shortmax.com/api";
const SM_HEADERS = {
  "User-Agent": "okhttp/4.12.0",
  "platform": "h5",
};

app.get("/api/shortmax/latest", async (req, res) => {
  try {
    const data = await fetchJSON(`${SM_BASE}/drama/list?page=1&pageSize=20&sort=latest`, SM_HEADERS);
    const dramas = (data?.data?.list || data?.results || []).map((item) => ({
      shortPlayId: item.id || item.shortPlayId,
      title: item.name || item.title,
      cover: item.cover || item.picUrl || "",
      totalEpisodes: item.totalEpisodes || item.episodeCount || 0,
      label: item.label || "",
      collectNum: item.collectNum || 0,
    }));
    return ok(res, { success: true, data: dramas });
  } catch (e) {
    console.error("SM latest:", e.message);
    return ok(res, { success: true, data: [] });
  }
});

app.get("/api/shortmax/foryou", async (req, res) => {
  const page = req.query.page || 1;
  try {
    const data = await fetchJSON(`${SM_BASE}/drama/list?page=${page}&pageSize=20`, SM_HEADERS);
    const dramas = (data?.data?.list || []).map((item) => ({
      shortPlayId: item.id || item.shortPlayId,
      title: item.name || item.title,
      cover: item.cover || "",
      totalEpisodes: item.totalEpisodes || 0,
      label: item.label || "",
    }));
    return ok(res, { success: true, data: dramas });
  } catch (e) {
    return ok(res, { success: true, data: [] });
  }
});

app.get("/api/shortmax/detail", async (req, res) => {
  const { shortPlayId } = req.query;
  if (!shortPlayId) return fail(res, "shortPlayId required", 400);
  try {
    const data = await fetchJSON(`${SM_BASE}/drama/detail?id=${shortPlayId}`, SM_HEADERS);
    const d = data?.data || data;
    return ok(res, {
      success: true,
      shortPlayId: d.id || shortPlayId,
      title: d.name || d.title,
      cover: d.cover || d.picUrl || "",
      description: d.summary || d.desc || "",
      labels: (d.labelResponseList || d.labels || []).map((l) => l.labelName || l),
      totalEpisodes: d.totalEpisodes || d.episodeCount || 0,
    });
  } catch (e) {
    return fail(res, e.message);
  }
});

app.get("/api/shortmax/episode", async (req, res) => {
  const { shortPlayId, episodeNo } = req.query;
  if (!shortPlayId) return fail(res, "shortPlayId required", 400);
  try {
    const data = await fetchJSON(
      `${SM_BASE}/drama/episode/detail?dramaId=${shortPlayId}&episodeNo=${episodeNo || 1}`,
      SM_HEADERS
    );
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

app.get("/api/shortmax/search", async (req, res) => {
  const { keyword } = req.query;
  if (!keyword) return ok(res, { success: true, data: [] });
  try {
    const data = await fetchJSON(
      `${SM_BASE}/drama/search?keyword=${encodeURIComponent(keyword)}&page=1&pageSize=20`,
      SM_HEADERS
    );
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, { success: true, data: [] });
  }
});

app.get("/api/shortmax/rekomendasi", async (req, res) => {
  return res.redirect("/api/shortmax/latest");
});

app.get("/api/shortmax/hls", async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).send("Missing url");
  try {
    const upstream = await axios({ method: "GET", url, responseType: "stream" });
    res.setHeader("Content-Type", upstream.headers["content-type"] || "application/vnd.apple.mpegurl");
    res.setHeader("Access-Control-Allow-Origin", "*");
    upstream.data.pipe(res);
  } catch (e) {
    res.status(500).send("HLS error");
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  NETSHORT
// ══════════════════════════════════════════════════════════════════════════════
const NS_BASE = "https://api.netshort.net/api";
const NS_HEADERS = { "User-Agent": "okhttp/4.12.0" };

app.get("/api/netshort/theaters", async (req, res) => {
  try {
    const data = await fetchJSON(`${NS_BASE}/shortPlay/homeGroup`, NS_HEADERS);
    const groups = (data?.data || []).map((group) => ({
      groupId: group.groupId,
      groupName: group.contentName || group.groupName,
      dramas: (group.contentInfos || group.dramas || []).map((item) => ({
        shortPlayId: item.shortPlayId,
        shortPlayLibraryId: item.shortPlayLibraryId,
        title: item.shortPlayName || item.title,
        cover: item.shortPlayCover || item.cover || "",
        labels: item.labelArray || [],
        heatScore: item.heatScoreShow || "",
        totalEpisodes: item.totalEpisode || 0,
      })),
    }));
    return ok(res, { success: true, data: groups });
  } catch (e) {
    console.error("NS theaters:", e.message);
    return ok(res, { success: true, data: [] });
  }
});

app.get("/api/netshort/foryou", async (req, res) => {
  const page = req.query.page || 1;
  try {
    const data = await fetchJSON(
      `${NS_BASE}/shortPlay/list?page=${page}&pageSize=20`,
      NS_HEADERS
    );
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, []);
  }
});

app.get("/api/netshort/search", async (req, res) => {
  const { keyword } = req.query;
  if (!keyword) return ok(res, { data: [] });
  try {
    const data = await fetchJSON(
      `${NS_BASE}/shortPlay/search?keyword=${encodeURIComponent(keyword)}&page=1&pageSize=20`,
      NS_HEADERS
    );
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, { data: [] });
  }
});

app.get("/api/netshort/detail", async (req, res) => {
  const { shortPlayId } = req.query;
  if (!shortPlayId) return fail(res, "shortPlayId required", 400);
  try {
    const data = await fetchJSON(
      `${NS_BASE}/shortPlay/allEpisode?shortPlayId=${shortPlayId}`,
      NS_HEADERS
    );
    const d = data?.data || {};
    const episodes = (d.shortPlayEpisodeInfos || []).map((ep) => ({
      episodeId: ep.episodeId,
      episodeNo: ep.episodeNo,
      cover: ep.episodeCover || "",
      videoUrl: ep.playVoucher || "",
      quality: ep.playClarity || "720p",
      isLock: ep.isLock || 0,
      subtitleUrl: ep.subtitleList?.[0]?.url || "",
    }));
    return ok(res, {
      success: true,
      shortPlayId: d.shortPlayId,
      title: d.shortPlayName,
      cover: d.shortPlayCover,
      description: d.shotIntroduce || "",
      labels: d.shortPlayLabels || [],
      totalEpisodes: d.totalEpisode || episodes.length,
      episodes,
    });
  } catch (e) {
    return fail(res, e.message);
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  MELOLO
// ══════════════════════════════════════════════════════════════════════════════
const ML_BASE = "https://api.melolo.vip/api";
const ML_HEADERS = { "User-Agent": "okhttp/4.12.0", "version": "2.0.0" };

app.get("/api/melolo/latest", async (req, res) => {
  try {
    const data = await fetchJSON(`${ML_BASE}/book/list?pageNum=1&pageSize=20&sort=new`, ML_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    console.error("ML latest:", e.message);
    return ok(res, { rows: [] });
  }
});

app.get("/api/melolo/trending", async (req, res) => {
  try {
    const data = await fetchJSON(`${ML_BASE}/book/list?pageNum=1&pageSize=20&sort=hot`, ML_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    return ok(res, { rows: [] });
  }
});

app.get("/api/melolo/foryou", async (req, res) => {
  const page = req.query.page || 1;
  try {
    const data = await fetchJSON(`${ML_BASE}/book/list?pageNum=${page}&pageSize=20`, ML_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    return ok(res, { rows: [] });
  }
});

app.get("/api/melolo/search", async (req, res) => {
  const { keyword } = req.query;
  if (!keyword) return ok(res, { data: [] });
  try {
    const data = await fetchJSON(
      `${ML_BASE}/book/search?keyword=${encodeURIComponent(keyword)}&pageNum=1&pageSize=20`,
      ML_HEADERS
    );
    return ok(res, data?.data || data);
  } catch (e) {
    return ok(res, { data: [] });
  }
});

app.get("/api/melolo/detail", async (req, res) => {
  const { bookId } = req.query;
  if (!bookId) return fail(res, "bookId required", 400);
  try {
    const data = await fetchJSON(`${ML_BASE}/book/detail?bookId=${bookId}`, ML_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

app.get("/api/melolo/stream", async (req, res) => {
  const { videoId } = req.query;
  if (!videoId) return fail(res, "videoId required", 400);
  try {
    const data = await fetchJSON(`${ML_BASE}/video/stream?videoId=${videoId}`, ML_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  FREEREELS
// ══════════════════════════════════════════════════════════════════════════════
const FR_BASE = "https://www.freereels.net/api";
const FR_HEADERS = { "User-Agent": "okhttp/4.12.0" };

app.get("/api/freereels/home", async (req, res) => {
  try {
    const data = await fetchJSON(`${FR_BASE}/homepage`, FR_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    console.error("FR home:", e.message);
    return ok(res, []);
  }
});

app.get("/api/freereels/foryou", async (req, res) => {
  const page = req.query.page || 1;
  try {
    const data = await fetchJSON(`${FR_BASE}/book/list?pageNum=${page}&pageSize=20`, FR_HEADERS);
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, []);
  }
});

app.get("/api/freereels/search", async (req, res) => {
  const { keyword } = req.query;
  if (!keyword) return ok(res, []);
  try {
    const data = await fetchJSON(
      `${FR_BASE}/book/search?keyword=${encodeURIComponent(keyword)}`,
      FR_HEADERS
    );
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, []);
  }
});

app.get("/api/freereels/detail", async (req, res) => {
  const { id } = req.query;
  if (!id) return fail(res, "id required", 400);
  try {
    const data = await fetchJSON(`${FR_BASE}/book/detail?key=${id}`, FR_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

app.get("/api/freereels/anime", async (req, res) => {
  try {
    const data = await fetchJSON(`${FR_BASE}/book/list?pageNum=1&pageSize=20&type=anime`, FR_HEADERS);
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, []);
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  DRAMANOVA
// ══════════════════════════════════════════════════════════════════════════════
const DN_BASE = "https://api.dramanova.net/api";
const DN_HEADERS = { "User-Agent": "okhttp/4.12.0" };

app.get("/api/dramanova/home", async (req, res) => {
  try {
    const data = await fetchJSON(`${DN_BASE}/drama/home`, DN_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    console.error("DN home:", e.message);
    return ok(res, { rows: [] });
  }
});

app.get("/api/dramanova/search", async (req, res) => {
  const { keyword } = req.query;
  if (!keyword) return ok(res, []);
  try {
    const data = await fetchJSON(
      `${DN_BASE}/drama/search?keyword=${encodeURIComponent(keyword)}&pageNum=1&pageSize=20`,
      DN_HEADERS
    );
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, []);
  }
});

app.get("/api/dramanova/detail", async (req, res) => {
  const { dramaId } = req.query;
  if (!dramaId) return fail(res, "dramaId required", 400);
  try {
    const data = await fetchJSON(`${DN_BASE}/drama/detail?dramaId=${dramaId}`, DN_HEADERS);
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

app.get("/api/dramanova/getvideo", async (req, res) => {
  const { dramaId, episodeId } = req.query;
  if (!dramaId || !episodeId) return fail(res, "dramaId and episodeId required", 400);
  try {
    const data = await fetchJSON(
      `${DN_BASE}/drama/episode/video?dramaId=${dramaId}&episodeId=${episodeId}`,
      DN_HEADERS
    );
    return ok(res, data?.data || data);
  } catch (e) {
    return fail(res, e.message);
  }
});

app.get("/api/dramanova/drama18", async (req, res) => {
  try {
    const data = await fetchJSON(`${DN_BASE}/drama/list?type=18&pageNum=1&pageSize=20`, DN_HEADERS);
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, []);
  }
});

app.get("/api/dramanova/komik", async (req, res) => {
  try {
    const data = await fetchJSON(`${DN_BASE}/drama/list?type=comic&pageNum=1&pageSize=20`, DN_HEADERS);
    return ok(res, data?.data || []);
  } catch (e) {
    return ok(res, []);
  }
});

// ══════════════════════════════════════════════════════════════════════════════
//  PROXY VIDEO (subtitle / video generic)
// ══════════════════════════════════════════════════════════════════════════════
app.get("/api/proxy/video", async (req, res) => {
  const { url } = req.query;
  if (!url) return res.status(400).send("Missing url");
  try {
    const upstream = await axios({
      method: "GET",
      url,
      responseType: "stream",
      headers: {
        "User-Agent": "okhttp/4.12.0",
        "Accept": "*/*",
        "Range": req.headers.range || "",
      },
      httpsAgent: new https.Agent({ rejectUnauthorized: false }),
      maxRedirects: 5,
    });
    res.setHeader("Content-Type", upstream.headers["content-type"] || "application/octet-stream");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Accept-Ranges", "bytes");
    if (upstream.headers["content-length"])
      res.setHeader("Content-Length", upstream.headers["content-length"]);
    if (upstream.headers["content-range"])
      res.setHeader("Content-Range", upstream.headers["content-range"]);
    res.status(upstream.status);
    upstream.data.pipe(res);
  } catch (e) {
    res.status(500).send("Proxy error: " + e.message);
  }
});

app.get("/api/proxy/warmup", (req, res) => res.json({ ok: true }));

// ─── Health check ─────────────────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.json({
    name: "DracinBoss API",
    version: "1.0.0",
    status: "running",
    endpoints: [
      "/api/dramabox/latest", "/api/dramabox/trending", "/api/dramabox/dubindo",
      "/api/dramabox/foryou", "/api/dramabox/search", "/api/dramabox/detail",
      "/api/dramabox/allepisode", "/api/dramabox/decrypt-stream",
      "/api/reelshort/homepage", "/api/reelshort/foryou", "/api/reelshort/search",
      "/api/reelshort/detail", "/api/reelshort/episode",
      "/api/shortmax/latest", "/api/shortmax/foryou", "/api/shortmax/detail",
      "/api/shortmax/episode", "/api/shortmax/search", "/api/shortmax/hls",
      "/api/netshort/theaters", "/api/netshort/foryou", "/api/netshort/search",
      "/api/netshort/detail",
      "/api/melolo/latest", "/api/melolo/trending", "/api/melolo/foryou",
      "/api/melolo/search", "/api/melolo/detail", "/api/melolo/stream",
      "/api/freereels/home", "/api/freereels/foryou", "/api/freereels/search",
      "/api/freereels/detail", "/api/freereels/anime",
      "/api/dramanova/home", "/api/dramanova/search", "/api/dramanova/detail",
      "/api/dramanova/getvideo", "/api/dramanova/drama18", "/api/dramanova/komik",
      "/api/proxy/video",
    ],
  });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`✅ DracinBoss API running at http://localhost:${PORT}`);
});
